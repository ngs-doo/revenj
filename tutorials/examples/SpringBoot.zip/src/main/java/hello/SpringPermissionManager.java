package hello;

import org.revenj.patterns.Query;
import org.revenj.patterns.Specification;
import org.revenj.security.PermissionManager;

import javax.servlet.ServletContext;
import java.io.Closeable;
import java.security.Principal;
import java.util.List;

class SpringPermissionManager implements PermissionManager {

	private final ServletContext servletContext;

	public SpringPermissionManager(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	@Override
	public boolean canAccess(String identifier, Principal user) {
		//user is Servlet provided principal
		//while we could implement security checks here, we will use Spring security instead
		//and just pass through here
		return true;
	}

	@Override
	public <T, S extends T> Query<S> applyFilters(Class<T> manifest, Principal user, Query<S> data) {
		return data;
	}

	@Override
	public <T, S extends T> List<S> applyFilters(Class<T> manifest, Principal user, List<S> data) {
		return data;
	}

	@Override
	public <T> Closeable registerFilter(Class<T> manifest, Specification<T> filter, String role, boolean inverse) {
		return null;
	}
}
