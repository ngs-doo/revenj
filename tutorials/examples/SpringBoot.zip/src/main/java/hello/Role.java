package hello;

public enum Role {
	ADMIN,
	USER,
	GUEST;
}
